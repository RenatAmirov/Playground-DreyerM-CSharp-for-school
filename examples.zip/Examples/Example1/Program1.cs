﻿using System;
class PleaseSayUra
{
    static void Main()
    {
        // Выводим слово на экран
        Console.Write("Ура!");
        // Ожидаем нажатия клавиши ВВОД
        Console.ReadLine();
    }
}


